
<?php
 include "./../newspaper-header/header.php"; 
 include './../template/connection.php';
    
 if(isset($_GET['detail'])&&($_GET['detail'])=='details'){


    $query = $connection->prepare("SELECT * FROM `post` WHERE `id` =:id");
    $query->execute(['id'=>$_GET['id']]);
    $abc=$query->fetchAll(PDO::FETCH_ASSOC);
   foreach($abc as $key=>$value){}
   

   }
  
  ?>


      <body>
        <div class="container-scroller">
          <div class="main-panel">
            <!-- partial:partials/_navbar.html -->
            <header id="header">
              <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                  <div class="navbar-top">
                    <div class="d-flex justify-content-between align-items-center">
                      <ul class="navbar-top-left-menu">
                        <li class="nav-item">
                          <a href="pages/index-inner.html" class="nav-link">Advertise</a>
                        </li>
                        <li class="nav-item">
                          <a href="pages/aboutus.html" class="nav-link">About</a>
                        </li>
                        <li class="nav-item">
                          <a href="#" class="nav-link">Events</a>
                        </li>
                        <li class="nav-item">
                          <a href="#" class="nav-link">Write for Us</a>
                        </li>
                        <li class="nav-item">
                          <a href="#" class="nav-link">In the Press</a>
                        </li>
                      </ul>
                      <ul class="navbar-top-right-menu">
                        <li class="nav-item">
                          <a href="#" class="nav-link"><i class="mdi mdi-magnify"></i></a>
                        </li>
                        <li class="nav-item">
                          <a href="http://localhost/admin-panel/post/register-post.php" class="nav-link">upload news here</a>
                        </li>
                        <li class="nav-item">
                          <a href="#" class="nav-link">Sign in</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="navbar-bottom">
                    <div class="d-flex justify-content-between align-items-center">
                      <div>
                        <a class="navbar-brand" href="#"
                          ><img src="./../newspaper-header/logo.svg" alt=""
                        /></a>
                      </div>
                      <div>
                        <button
                          class="navbar-toggler"
                          type="button"
                          data-target="#navbarSupportedContent"
                          aria-controls="navbarSupportedContent"
                          aria-expanded="false"
                          aria-label="Toggle navigation"
                        >
                          <span class="navbar-toggler-icon"></span>
                        </button>
                        <div
                          class="navbar-collapse justify-content-center collapse"
                          id="navbarSupportedContent"
                        >
                          <ul
                            class="navbar-nav d-lg-flex justify-content-between align-items-center"
                          >
                            <li>
                              <button class="navbar-close">
                                <i class="mdi mdi-close"></i>
                              </button>
                            </li>
                            <li class="nav-item active">
                              <a class="nav-link" href="http://localhost/admin-panel/newspaper-crud/newspaper-index.php">Home</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="pages/magazine.html">MAGAZINE</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="pages/business.html">Business</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="pages/sports.html">Sports</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="pages/art.html">Art</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="pages/politics.html">POLITICS</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="pages/travel.html">Travel</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="/opt/lampp/htdocs/admin-panel/newspaper-crud/admin-page.php">Contact</a>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <ul class="social-media">
                        <li>
                          <a href="https://www.facebook.com/  ">
                            <i class="bi bi-facebook  "><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16  16">
      <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z"/>
    </svg></i>
                          </a>
                        </li>
                        <li>
                          <a href="https://www.youtube.com/">
                          <i class="bi bi-youtube"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-youtube" viewBox="0 0 16 16">
      <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.108-.082 2.06l-.008.105-.009.104c-.05.572-.124 1.14-.235 1.558a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.122C.002 7.343.01 6.6.064 5.78l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c.487-.13 1.544-.21 2.654-.26l.17-.007.172-.006.086-.003.171-.007A99.788 99.788 0 0 1 7.858 2h.193zM6.4 5.209v4.818l4.157-2.408L6.4 5.209z"/>
    </svg></i>
                      </a>
                    </li>
                    <li>
                      <a href="https://twitter.com/">
                      <i class="bi bi-twitter"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-twitter" viewBox="0 0 16 16">
    <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
    </svg></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
        </header>
        
        
        <br><br><br><br>

        <h2 style="background-color:black;color:#fff;width:2000px;text-align:center;padding:10px;">Full Information </h2>
                       
               <br><br><br><br>







                       <div class="col-sm-8  grid-margin">

                      
                       
                       <div  style="color:blue  ;  font-weight: bold; ">
                    <i> <?php echo 'TITLE:-   '.strtoupper($value['title']); ?>  </i>  <br>
                     </div>
                         <h2 class="mb-2 font-weight-600">
 
                         <img src="./../post-img/<?php echo $value['image']; ?>" style="text-align-left" width="400px" height="200px" />
                              
                                 
                         </h2>
                         <div class="fs-13 mb-2">
                           <span class="mr-2"></span>  <?php echo "Posted On  :". $value['create']; ?>
                         </div>
                         <p class="mb-0">
                         <i>  <?php echo 'DESCRIPTION:-   '.$value['description']; ?> </i>  
                         <hr>
                          <br> <br> <br>
                         
                         </p>
                           










      
              <div class="col-lg-9 stretch-card grid-margin">
                <div class="card">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-sm-4 grid-margin">
                        <div class="position-relative">
                          <div class="rotate-img">
                            
                          </div>
                          <div class="badge-positioned">
                            <span class="badge badge-danger font-weight-bold"
                              ></span
                            >
                          </div>
                        </div>
                      </div>




                      </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-4 grid-margin">
                        <div class="position-relative">
                          <div class="rotate-img">
                       
                          </div>
                          <div class="badge-positioned">
                            
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-8  grid-margin">
                        <h2 class="mb-2 font-weight-600">
                         
                        <div class="fs-13 mb-2">
                          
                        </div>
                     
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-4">
                        <div class="position-relative">
                          <div class="rotate-img">
                         
                          </div>
                          <div class="badge-positioned">
                          
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-8">
                       
                        <div class="fs-13 mb-2">
                          
                        </div>
                    
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
           

     






           
        <footer>
          <div class="footer-top">
            <div class="container">
              <div class="row">
                <div class="col-sm-5">
                  <img src="./../newspaper-header/logo.svg" class="footer-logo" alt="" />
                  <h5 class="font-weight-normal mt-4 mb-5">
                    Newspaper is your news, entertainment, music fashion website. We
                    provide you with the latest breaking news and videos straight from
                    the entertainment industry.
                  </h5>
                  <ul class="social-media mb-3">
                    <li>
                      <a href="#">
                        <i class="mdi mdi-facebook"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="mdi mdi-youtube"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        <i class="mdi mdi-twitter"></i>
                      </a>
                    </li>
                  </ul>
                </div>
                <div class="col-sm-4">
                  <h3 class="font-weight-bold mb-3">RECENT POSTS</h3>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="footer-border-bottom pb-2">
                        <div class="row">
                          <div class="col-3">
                          <img
                              src="./../newspaper-header/home_1.jpg"
                              alt="thumb"
                              class="img-fluid"
                            />
                          </div>
                          <div class="col-9">
                            <h5 class="font-weight-600">
                              Cotton import from USA to soar was American traders
                              predict
                            </h5>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="footer-border-bottom pb-2 pt-2">
                        <div class="row">
                          <div class="col-3">
                          <img
                              src="./../newspaper-header/home_2.jpg"
                              alt="thumb"
                              class="img-fluid"
                            />
                          </div>
                          <div class="col-9">
                            <h5 class="font-weight-600">
                              Cotton import from USA to soar was American traders
                              predict
                            </h5>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-12">
                      <div>
                        <div class="row">
                          <div class="col-3">
                          <img
                              src="./../newspaper-header/home_3.jpg"
                              alt="thumb"
                              class="img-fluid"
                            />
                          </div>
                          <div class="col-9">
                            <h5 class="font-weight-600 mb-3">
                              Cotton import from USA to soar was American traders
                              predict
                            </h5>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-3">
                  <h3 class="font-weight-bold mb-3">CATEGORIES</h3>
                  <div class="footer-border-bottom pb-2">
                    <div class="d-flex justify-content-between align-items-center">
                      <h5 class="mb-0 font-weight-600">Magazine</h5>
                      <div class="count">1</div>
                    </div>
                  </div>
                  <div class="footer-border-bottom pb-2 pt-2">
                    <div class="d-flex justify-content-between align-items-center">
                      <h5 class="mb-0 font-weight-600">Business</h5>
                      <div class="count">1</div>
                    </div>
                  </div>
                  <div class="footer-border-bottom pb-2 pt-2">
                    <div class="d-flex justify-content-between align-items-center">
                      <h5 class="mb-0 font-weight-600">Sports</h5>
                      <div class="count">1</div>
                    </div>
                  </div>
                  <div class="footer-border-bottom pb-2 pt-2">
                    <div class="d-flex justify-content-between align-items-center">
                      <h5 class="mb-0 font-weight-600">Arts</h5>
                      <div class="count">1</div>
                    </div>
                  </div>
                  <div class="pt-2">
                    <div class="d-flex justify-content-between align-items-center">
                      <h5 class="mb-0 font-weight-600">Politics</h5>
                      <div class="count">1</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="footer-bottom">
            <div class="container">
              <div class="row">
                <div class="col-sm-12">
                  <div class="d-sm-flex justify-content-between align-items-center">
                    <div class="fs-14 font-weight-600">
                      © 2020 @ <a href="https://www.bootstrapdash.com/" target="_blank" class="text-white"> BootstrapDash</a>. All rights reserved.
                    </div>
                    <div class="fs-14 font-weight-600">
                      Handcrafted by <a href="https://www.bootstrapdash.com/" target="_blank" class="text-white">BootstrapDash</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </footer>

        <!-- partial -->
      </div>
    </div>
  
    <?php include "./../newspaper-header/footer.php";  ?>