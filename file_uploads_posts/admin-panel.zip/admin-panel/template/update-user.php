<?php
  include './connection.php' ;
  include './../header/main_header.php' ;
  include './../header/main-sidebar.php' ;
  include './../header/aside.php';
  include './../header/header.php';


  $warn=$warn1=$warn2=$warn3=$warn6=""; 


  $status = "";
  $check = $stmt = "";
  $id = $_GET['id'];
  $gender = "";
  $msg = "";
  if (isset($_POST['update'])){
  $username         = $_POST['username'];
  $email            = $_POST['email'];
  $password         = $_POST['password'];
  $gender           = !empty($_POST['gender']) ? $_POST['gender'] : ''; 
  $dateofbirth      = $_POST['dateofbirth'];
  $bio              = $_POST['bio'];
  $status           = $_POST['status'];
  $flag             = false;

  if(empty($username)){
    $flag = true;
    $warn = "username is required*";
  }
  if(empty($email)){
    $flag = true;
    $warn1 = "email is required*";
  }
 
  if(empty($password)){
    $flag = true;
    $warn3 = "password is required*";

  }
  if(empty($gender)){
    $flag = true;
    $warn2 = "gender is required*";
  }
  if(empty($dateofbirth)){
    $flag = true;
    $warn6 = "dob is required*";
  }
  if($flag == false){
  $query = "
    UPDATE 
      `prashantdata` 
    SET 
      `username`   = :u,
      `email`      = :e, 
      `password`   = :p,      
      `gender`     = :g, 
      `dateofbirth`= :d,
      `bio`        = :b,
      `status`     = :s
      
    WHERE 
      `id` =  :id
  ";


//$check = "update Error:";
//if ($mysqli->query($query) === TRUE){  
//  $check = "update Success";
//}
  $stmt = $connection->prepare($query);
  $update = $stmt->execute([
    "u" => $username,
    "e" => $email,
    "p" => $password,
    "g" => $gender,
    "d" => $dateofbirth,
    "b" => $bio,
    "s" => $status,
    "id"=> $id
  
  ]);
  if($update==true){
    $username         = "";
    $email            = "";
    $password         = "";
    $gender           = "";
    $dateofbirth      = "";
    $bio              = "";

    $check = "updated successfully";
    $success          = "btn btn-block btn-success btn-lg";
    $msg              = "Yay !! <br> Data updated successfully";
  }

else{
    //echo $pdo->error();
    $msg = "There is an error to insert data";
    $success = "alert alert-danger";
  }
  }
}
    $quer = $connection->prepare("SELECT * FROM `prashantdata` WHERE `id` = :id");
    $quer->execute(['id'=>$id]);
    $que  = $quer->fetch(PDO::FETCH_ASSOC);

?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Update here
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="./listing-user.php"><i class="fa fa-dashboard"></i>Listing</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
          <form class="form-horizontal" method="post" enctype="multipart/form-data" >
         


   
 
      <div class="<?php echo $success;?> " >
                 <?php echo $msg ?>
              </div>

                 
                 
                 <br>
                 
                 
                 
                 <div class="form-group">
                  <label for="username" class="col-sm-2 control-label">USERNAME:</label>
                  <div class="col-sm-5">
                    <input type="text" name="username" class="form-control" id="username" placeholder="username*" value="<?php echo !empty($que['username']) ? $que['username'] :'';?>">
                    <p style="color:red;"><?php echo $warn; ?></p>
                  </div>
                </div>

                <div class="form-group">
                  <label for="email" class="col-sm-2 control-label">E-MAIL:</label>
                  <div class="col-sm-5">
                    <input type="email"  name="email" class="form-control" id="email" placeholder="email*" value="<?php echo !empty($que['email']) ? $que['email'] :'';?>">
                    <p style="color:red;"><?php echo $warn1; ?></p>
                  </div>
                </div>

                <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">PASSWORD:</label>
                  <div class="col-sm-5">
                    <input type="password" name="password" class="form-control" id="password" placeholder="password*" value="<?php echo !empty($que['password']) ? $que['password'] :'';?>">
                    <p style="color:red;"><?php echo $warn3; ?></p>
                  </div>
                </div>

                <div class="form-group">
                  
                <div class="radio-button">
                <label for = "gender" class="col-sm-2 control-label"><b>GENDER:</b></label>
                    <div class = col-sm-10>
                <?php
                  foreach($genderFields as $value => $label){
                    $checked = ($value == $que['gender']) ? 'checked' : '';
                ?>
                
                  <label class="form-check-label" for="male">
                    <?php echo $label; ?>
                  </label> &nbsp; &nbsp;
                    
                  <input class="form-check-input" type="radio" name="gender"  value = "<?php echo $value; ?>" <?php  echo $checked; ?> id="flexRadioDefault1" />  
                <?php } ?>
                  <p style="color:red;"><?php echo $warn2; ?></p>
                  </div> 
                  </div>
                  </div>
          

              <div class="form-group">
              <label for="dateofbirth" class="col-sm-2 control-label">DATE OF BIRTH:</label>
              <div class="col-sm-5">
                <input type="date" class="form-control" name="dateofbirth" id="dateofbirth" placeholder="date of birth*" value="<?php echo !empty($que['dateofbirth']) ? $que['dateofbirth'] :'';?>">
                <p style="color:red;float:"><?php echo $warn6; ?></p>
              </div>
            </div>




            <div class="form-group">
              <label for="bio" class="col-sm-2 control-label">BIO:</label>
              <div class="col-sm-5">
                <input type="text" class="form-control" name="bio" id="dateofbirth" placeholder="bio*" value="<?php echo !empty($que['bio']) ? $que['bio'] :'';?>">
              </div>
            </div><br>

           
        <div class="form-group"> 
        <label for="status" class="col-sm-2 control-label">STATUS:  </label> 
          <select name="status" id="status" style="width:680px;font-size:150%">
            <option value="system"   <?php if(isset($_POST['status']) && $_POST['status']=="system"){echo"selected";} ?>>system</option>
            <option value="admin"   <?php if(isset($_POST['status']) && $_POST['status']=="admin"){echo"selected";} ?>>admin</option>
            <option value="user"   <?php if(isset($_POST['status']) && $_POST['status']=="user"){echo"selected";} ?>>user</option>
          </select>
          </div>

            <div class="form-group" style="text-align:center;">
            <button type="submit" name="update" class="btn btn-primary" style="padding:2%;width:200px;padding: 1%;margin: 30px;font-size: x-large;">update</button>
          </div>
        </form>
            

  

              <!-- /.box-footer -->
         
          </div>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->



<?php include './../footer/footer.php'; ?>
