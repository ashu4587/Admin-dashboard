    
<?php
  include './connection.php' ;
  include './../header/main_header.php' ;
  include './../header/main-sidebar.php' ;
  include './../header/aside.php';
  include './../header/header.php';


$msg=$success= $warn =$warn1 =$warn2 =$warn3 =$warn4 =$warn5=$warn6=$gender =$flag =$query="";

if(isset($_POST['submit'])){
  if(isset($_FILES['image'])){ 
  $errors     = array();
  $file_name  = $_FILES['image']['name'];
  $file_size  = $_FILES['image']['size'];
  $file_tmp   = $_FILES['image']['tmp_name'];
  $file_type  = $_FILES['image']['type'];
  $ext        = explode('.',$file_name);
  $name       = $ext[0];
  $file_ext   = strtolower(end($ext));
  $extensions = array("jpeg","jpg","png","");

  if(in_array($file_ext,$extensions)===false){
    $errors[] = "this extension file not allowed , please choose ajpg or png file";
  }
  if(empty($errors)==true){
    move_uploaded_file($file_tmp,"../img/".$file_name);
  }else{
    print_r($errors);
    die(); 
  }
  }




  $username        = $_POST['username'];
  $email           = $_POST['email'];
  $password        = $_POST['password'];
  $gender          = !empty($_POST['gender']) ? $_POST['gender'] : '';
  $dateofbirth     = $_POST['dateofbirth'];
  $bio             = $_POST['bio'];

  if(empty($username)){
    $flag = true;
    $warn = "username is required*";
  }
  if(empty($email)){
    $flag = true;
    $warn1 = "email is required*";
  }
 
  if(empty($password)){
    $flag = true;
    $warn3 = "password is required*";

  }
  if(empty($gender)){
    $flag = true;
    $warn2 = "gender is required*";
  }
  if(empty($dateofbirth)){
    $flag = true;
    $warn6 = "dob is required*";
  }
  if($flag == false){
 
  
    $query = "INSERT INTO `prashantdata`
    (`username`, `email`, `password`, `gender`,`dateofbirth`,`bio`,`image`,`status`)
    VALUES (:u,:e,:p,:g,:d,:b,:i,:s)";
    //print_r($query);
    $insert = $connection->prepare($query );
    $insert->execute([  
        'u'  => $username,
        'e'  => $email,
        'p'  => $password,
        'g'  => $gender,
        'd'  => $dateofbirth,
        'b'  => $bio,
        'i'  => $file_name,
      
        's'  => 'system',
        ]);
  
   
   
    if($insert == true){
      $username         = "";
      $email            = "";
      $password           = "";
      $gender           = "";
      $dateofbirth      = "";
      $bio              = "";
      $file_name        = "";
     
      $success          = "btn btn-block btn-success btn-lg";
      //header
      $msg              = "Yay !! <br> Data inserted successfully";
    }else{
      //echo $mysqli->error;
      $msg = "There is an error to insert data";
      $success = "alert alert-danger";
    }
  }
}


?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       sign up
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="listing-user.php"><i class="fa fa-dashboard"></i>Listing</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
 

        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
          <form class="form-horizontal" method="post" enctype="multipart/form-data" > 
          <div class="<?php  echo $success;?> "   >
                 <?php echo  $msg ?>
              </div>

             <br>

               <div class="form-group">
                  <label for="username" class="col-sm-2 control-label">USERNAME:</label>
                  <div class="col-sm-5">
                    <input type="text" name="username" class="form-control" id="username" placeholder="username*"value="<?php echo(!empty($username)? $username:'');?>">
                    <p style="color:red;"><?php echo $warn; ?></p>
                  </div>
                </div>

              

                <div class="form-group">
                  <label for="email" class="col-sm-2 control-label">E-MAIL:</label>
                  <div class="col-sm-5">
                    <input type="email"  name="email" class="form-control" id="email" placeholder="email*" value="<?php echo(!empty($email)? $email:'');?>">
                    <p style="color:red;"><?php echo $warn1; ?></p>
                  </div>
                </div>

                <div class="form-group">
                  <label for="password" class="col-sm-2 control-label">PASSWORD:</label>
                  <div class="col-sm-5">
                    <input type="password" name="password" class="form-control" id="password" placeholder="password*" value="<?php echo(!empty($password)? $password:'');?>">
                    <p style="color:red;"><?php echo $warn3; ?></p>
                  </div>
                </div>

                <div class="form-group">
                  
                <div class="radio-button">
                <label for = "gender" class="col-sm-2 control-label"><b>GENDER:</b></label>
                    <div class = col-sm-10>
                <?php
                  foreach($genderFields as $value => $label){
                  $checked = ($value == $gender) ? 'checked' : '';
                ?>
                
                  <label class="form-check-label" for="male">
                    <?php echo $label; ?>
                  </label> &nbsp; &nbsp;
                    
                  <input class="form-check-input" type="radio" name="gender"  value = "<?php echo $value; ?>" <?php  echo $checked; ?> id="flexRadioDefault1" />  
                <?php } ?>
                  <p style="color:red;"><?php echo $warn2; ?></p>
                  </div> 
                  </div>
                  </div>
          

              <div class="form-group">
              <label for="dateofbirth" class="col-sm-2 control-label">DATE OF BIRTH:</label>
              <div class="col-sm-5">
                <input type="date" class="form-control" name="dateofbirth" id="dateofbirth" placeholder="date of birth*" value="<?php echo(!empty($dateofbirth)? $dateofbirth:'');?>">
                <p style="color:red;float:"><?php echo $warn6; ?></p>
              </div>
            </div>




            <div class="form-group">
              <label for="bio" class="col-sm-2 control-label">BIO:</label>
              <div class="col-sm-5">
                <input type="text" class="form-control" name="bio" id="dateofbirth" placeholder="bio*" value="<?php echo(!empty($bio)? $bio:'');?>">
              </div>
            </div><br>

            <div class="form-group">
              <label for="image" class="col-sm-2 control-label">IMAGE:</label>
              <div class="col-sm-5">
                <input type="file" class="form-control" name="image"  id="image" value="<?php echo(!empty($file_name)? $file_name:'');?>">
        
              </div>
            </div>



            
            

            <div class="form-group" style="text-align:center;">
            <button type="submit" name="submit" class="btn btn-primary" style="padding:2%;width:200px;padding: 1%;margin: 30px;font-size: x-large;">Submit</button>
          </div>
        </form>

              <!-- /.box-footer -->
         
          </div>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include './../footer/footer.php'; ?>
