<?php include './../header/main-sidebar.php' ?>
<?php include './../header/main_header.php' ?>
<?php include './../header/header.php' ?>
<form class="form" method="post" action="" style="float:right;background-color:white;width: 1150px;">
  <div class="box-body">
     <h1>SignUp</h1></br>

    <div class="form-group" style="width: 400px;">
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username"  class="form-control" >
    </div>

    <div class="form-group" style="width: 400px;">
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
    </div>

    <div class="form-group"style="width: 400px;">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
    </div>

    <div class="form-group"style="width: 400px;">
    <label for="exampleInputPassword1">Gender:</label></br>
    <input type="radio" id="male" name="gender" value="male">
    <label for="male">Male</label><br>
    <input type="radio" id="female" name="gender" value="female">
    <label for="female">Female</label><br>
    <input type="radio" id="other" name="gender" value="other">
    <label for="other">Other</label>
    </div>

    <div class="form-group"style="width: 400px;">
    <label for="exampleInputPassword1">Interest:</label></br>
    <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
    <label for="vehicle1"> I have a bike</label><br>
    <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
    <label for="vehicle2"> I have a car</label><br>
    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
    <label for="vehicle3"> I have a boat</label><br>
    </div>

    <div class="form-group" style="width: 400px;">
    <label for="companyname"><b>company name</b></label>
    <input type="text" placeholder="Enter company name" name="companyname"  class="form-control" >
    </div>
    

    <div class="form-group" style="width: 400px;">
    <label for="dateofbirth"><b>date of birth</b></label>
    <input type="date" id="birthday" name="birthday"  class="form-control">
    </div>

    <div class="form-group" style="width: 400px;">
    <label for="dateofbirth"><b>message</b></label>
    <textarea id="w3review" name="w3review" rows="4" cols="50">
    </textarea>
    </div>

    <div class="form-group" style="width: 400px;">
    <label for="bio"><b>bio</b></label>
    <input type="text" placeholder="Enter bio" name="bio"  class="form-control" >
    </div>

    <div class="form-group" style="width: 400px;">
    <label for="exampleInputFile">image upload</label>
    <input type="file" id="exampleInputFile"  class="form-control">
    </div>
  
    <div class="form-group" >
      <button type="submit" class="btn btn-primary" style="width:200;padding:2%;width: 200;padding: 1%;margin: 30px;font-size: x-large;">Submit</button>
    </div>
  </form>
</div>
<!-- /.box -->

  
<?php include './../footer/footer.php'; ?>
