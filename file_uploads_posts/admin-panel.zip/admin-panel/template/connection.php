<?php
try {
    $dsn    = "mysql:host=localhost;dbname=prashant";
    $user   = "root";
    $passwd = "";
    $connection = new PDO($dsn, $user, $passwd);
    if($connection==true){
        //echo "connection success";
    }
    // throw new Exception("This field is required");
    
    // if( $p != $cp ){
    //   throw new Exception("pasfd");
    // }
    #insert
    #Exception
    }catch (PDOException $e) {
      echo "Error : " . $e->getMessage() . "<br/>";
      
    }	 

    function debug($args){
        echo "<pre>";
          print_r($args);
        echo "</pre>";
      }


      $genderFields = [
        'male' => 'Male',
        'female' => 'Female',
        'other' => 'Other',
      ];

    // start session
    session_start();


    ?>