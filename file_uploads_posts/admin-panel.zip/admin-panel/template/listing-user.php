<?php
  include './connection.php' ;
  include './../header/main_header.php' ;
  include './../header/main-sidebar.php' ;
  include './../header/aside.php';
  include './../header/header.php';
 

  if( 
    !isset($_SESSION['login_id']) 
 
  ){
    header("http://localhost/admin-panel/adminlte-login/login-crud/login.php");
  }


  $sort = $deletequery = $user =$msg= "";


  $search  = !empty($_POST['search'])  ? $_POST['search'] : '';
  $orderBy = !empty($_GET['orderBy']) ? $_GET['orderBy'] : 'id';  
  $order   = !empty($_GET['order'])   ? $_GET['order'] : 'asc';
  $page    = !empty($_GET['page'])    ? $_GET['page'] : 1;
  //$id = $_GET['id'];
  $perPage   = 10;
  $limitrec  = ( $page - 1) * $perPage;
  # single row delete

  if( isset( $_GET['action'] ) && $_GET['action'] == 'delete' ){
    // $query  = "DELETE FROM `TABLE` WHERE `id` = '{$_GET['id']}'";
     $query = $connection->prepare("DELETE FROM `prashantdata` WHERE `id` = :id");
     $query->execute(['id'=>$_GET['id']]);
     
     if( $query == false ){
       echo "Error : delete";
     }else{
      $message = '<div class="alert alert-success" style="width:500px;float:left;text-align:right;" role="alert">
            <h4 class="alert-heading">SUCCESSFULLY deleted !!</h4>
            <p></p></div>'; 
            echo $message ;
       //echo "Deleted successfully";
        //header('location:http://localhost/pankajProject/9876-main/pdo/listing4.php');
     }
   }

  # Multi Delete Records
  if( !empty($_POST['multiDelete']) ){
    $action = $_POST['multiDelete'];
    $user   = $_POST['user'];
    $ids    = implode(",",$user);

    switch ($action) {
      case 'allDelete':
        //foreach( $user as $id ){
        $deletequery = ("DELETE FROM `prashantdata` WHERE `id` IN ({$ids}) ");
        $stmt = $connection->prepare($deletequery);        //$query  = "DELETE FROM `TABLE` WHERE `id` = '$id'";
        // $query =  $pdo->prepare( "DELETE FROM `table` WHERE `id` = '$id'");
        //$query->bindValue(1, $id, PDO::PARAM_STR);
        //$query->execute();
        //$stmt->execute(['id'=>$id]);
        $stmt->execute();
        if( $deletequery == false ){
        echo "Error : delete";
        }else{
          $message = '<div class="alert alert-success" style="width:500px;float:left;text-align:right;" role="alert">
          <h4 class="alert-heading">SUCCESSFULLY deleted !!</h4>
          <p></p></div>'; 
          echo $message ;
          # TODO: display success message
        }
        //}  
      break;
      case 'user':
      case 'admin':
      case 'system':
        //foreach( $user as $id ){ 
          $link = $connection->prepare("UPDATE `prashantdata` SET `status` = :position WHERE `id`IN ({$ids})");
          $link->execute([
            //'id' => $ids,
            'position' => $action
            ]);   
          if( $link == false ){
          echo "Error detected while moving";
          }else{
            $message = '<div class="alert alert-success" style="width:500px;float:left;text-align:right;" role="alert">
            <h4 class="alert-heading">SUCCESSFULLY UPDATED !!</h4>
            <p></p></div>'; 
            echo $message ;
            #TODO: display success message
          }
        //}
      break;      
      default:
        # code...
      break;
    }

  }
  if(!empty( $_POST['search'] )){
    $search = " WHERE `username` LIKE :searchValue ||  `email` LIKE :searchValue ";
  }
 

  $order = ($order == 'asc') ? 'desc' : 'asc';
  if(!empty($orderBy) && !empty($order)){
      $sort = " ORDER BY `{$orderBy}` {$order}";
    }
  $query = "SELECT SQL_CALC_FOUND_ROWS * FROM `prashantdata` {$search} {$sort}  LIMIT :limitrec , :perPage ";

  #$result  = mysqli_query($con, $query);

  $fetch = $connection->prepare($query);
  if(!empty( $_POST['search'] )){
    $fetch-> bindValue(':searchValue', '%'.$_POST['search'].'%');
  }

  $fetch-> bindValue(':limitrec', $limitrec , PDO::PARAM_INT);
  $fetch-> bindValue(':perPage', $perPage, PDO::PARAM_INT);

  $fetch->execute();
  #$response   = $statement->fetchColumn();

  // $foundRow = $pdo->prepare("SELECT FOUND_ROWS() as totalRow");
  // $foundRow->execute();
  $fR = $connection->query("SELECT FOUND_ROWS() as totalRow");
  $tR = $fR->fetchColumn();
  $offset    = ceil( $tR / $perPage );
  $fetchall = $fetch->fetchAll(PDO::FETCH_ASSOC);
   
  
      
      
      ?>





<form method='post' action = '' enctype='multipart/form-data' >


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      listing
   
      </h1>
      <ol class="breadcrumb">
        <li><a href="listing-user.php"><i class="fa fa-dashboard"></i>Listing</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>
  

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
 

        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->

    <div class ="form-group has-search"style="float:left;padding:4px">

<input placeholder="Search..." name="search">

</form>
</div>
  



<div class="md" style="width:600px;float:right;">

    <div class = "select" >
    <select name = "multiDelete">
      <option value = "">SELECT</option>
      <option value = "allDelete">Delete</option>
      <option value = "user">Move to user</option>
      <option value = "system">Move to system</option>
      <option value = "admin">Move to admin</option>
    </select>
    <button class= "btn-danger"type="submit" name="all"  style="padding: 1px; width: 60px; " >Action</button>
    </div>
    </div>
  <br><br><br>

  <table class = "table table-bordered" style="text-align:">
    <thead thead class="thead-dark" >
      <tr>
        <th> Select</th>
        <th> Serial No.</th>
        <th scope = "col">
          <a href = "listing-user.php?orderBy=id&order=<?php echo $order; ?>">ID</a>
        </th>
        <th scope = "col">
          <a href = "listing-user.php?orderBy=username&order=<?php echo $order; ?>">Username</a> 
        </th>
        <th scope = "col">
          <a href = "listing-user.php?orderBy=email&order=<?php echo $order; ?>">Email</a>
        </th>
      
        <th scope = "col">
          <a href = "listing-user.php?orderBy=dateofbirth&order=<?php echo $order; ?>">Date of Birth</a>
        </th>
      
        <th scope = "col">
          <a href = "listing-user.php?orderBy=image&order=<?php echo $order; ?>">image</a>
        </th>

        

        <th scope = "col">
          status
        </th>
        <th scope = "col">
          Action
        </th>

     
        <th scope = "col">
          Posts here
        </th>
    </thead>
    <tbody class="tableBody" >

      <?php if(empty($fetchall)){ $fetchall = [];?>      
        <tr><td>No Record Found</td></tr>
      <?php  } ?>


      <?php foreach($fetchall as $key => $values){?>
        <tr>
          <td> <input type = "checkbox" name = "user[]" value = "<?php echo $values['id']; ?>"> </td>
          <td><?php echo ++$limitrec;?> </td>
          <td><?php echo $values['id'];?></td>
          <td><?php echo $values['username'];?></td>
          <td><?php echo $values['email']; ?></td> 
          <td><?php echo $values['dateofbirth'];  ?></td>


          <td>
            <?php
              if( !empty($values['image']) ){
            ?>
              <img src="./../img/<?php echo $values['image']; ?>" width="50" height="50"/>
           <?php
              } 
            ?>
         </td>

          <td><?php echo $values['status'];  ?></td>
          <td>
            <a href = "update-user.php?id=<?php echo $values['id'];  ?>"><i class="fa fa-edit" aria-hidden="true"></i> </a>
            <a href = "listing-user.php?id=<?php echo $values['id']; ?>&action=delete" ><i class="fa fa-trash" aria-hidden="true"></i> </a>
            <a href = "profile-user.php?id=<?php echo $values['id']; ?>&detail=details" ><i class="fa fa-eye" aria-hidden="true"></i> </a>
          </td>


          <td>
            <?php
              if( !empty($values['file']) ){

               
                $imageArray = explode(',', $values['file']);

                // echo "<pre>";
                // print_r(    $imageArray );
               

                foreach( $imageArray as $image ){?>
                
                  <img src="./../img/<?php echo $image; ?>" width="50" height="50"/>
                <?php  }


               


            ?>
           
           <?php
              } 
            ?>
        
          <a href = "http://localhost/admin-panel/post/register-post.php?id=<?php echo $values['id']; ?>" >Click to post </a>

        
          </td>
        </tr> 
      <?php } ?>     
    </tbody>
  </table>
</form>

  <!-- <div class="pagination" style="margin: 0 auto;width: 20%;">
  <nav aria-label="page navigation">
    //
    //<?php//for($i=1;$i<=$totalpages;$i++){
   //   echo "<a href='./listing2.php?page={$i}' style='color:#fff;margin-left: 9px;padding: 1px 11px;'>".$i."</a>";
   // } 
    //?> -->

<nav aria-label = "page navigation example" style="text-align:center">
  <ul class = "pagination justify-content-center">
    <!-- <li class = "page-item disabled">
      <a class = "previous" href = <?php //if($page <= 1){ echo "" ; } else { echo "listing2.php?page=".($page - 1); } ?>>previous</a>
    </li> -->

    <li class="page-item ">
      <a class="page-link disabled" href="<?php if($page <= 1){ echo "" ; } else { echo "listing-user.php?page=".($page - 1); } ?>" tabindex="-1">Previous</a>
    </li>

    <?php for($i=1;$i<=$offset;$i++){ ?>
      <li class = "page-item ">
      <a class = "page-link active" href = "listing-user.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
    <?php } ?>
      <!-- <li class="page-item disabled">       
        <a class = "next" href = <?php// if($page >= $totalpages){ echo ""; } else { echo "listing2.php?page=".($page + 1); } ?>>Next</a>
      </li> -->
     
    <li class="page-item ">
      <a class="page-link" href="<?php if($page >= $offset){ echo ""; } else { echo "listing-user.php?page=".($page + 1); } ?>" tabindex="+1">Next</a>
    </li>

  </ul>
</nav>

</div>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  </div>
  <!-- /.content-wrapper -->
  <?php include './../footer/footer.php'; ?>