<!DOCTYPE html>
<html lang="zxx">
  <head>
    <!-- Required meta tags -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>World Time</title>
    <!-- plugin css for this page -->
    <link
      rel="stylesheet"
      href="./../newspaper-css/materialdesignicons.min.css" />
    <link rel="stylesheet" href="./../newspaper-css/aos.css" />

    <!-- End plugin css for this page -->
    <link rel="shortcut icon" href="./../newspaper-header/favicon.png" />

    <!-- inject:css -->
    <link rel="stylesheet" href="./../newspaper-css/style.css">
    <!-- endinject -->
  </head>