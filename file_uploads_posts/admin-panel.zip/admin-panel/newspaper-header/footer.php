  <!-- inject:js -->
  <script src="./../newspaper-js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <script src="./../newspaper-js/aos.js"></script>
    <!-- End plugin js for this page -->
    <!-- Custom js for this page-->
    <script src="./../newspaper-js/demo.js"></script>
    <script src="./../newspaper-js/jquery.easeScroll.js"></script>
    <!-- End custom js for this page-->
  </body>
</html>