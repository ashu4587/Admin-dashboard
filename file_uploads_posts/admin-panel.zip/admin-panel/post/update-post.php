<?php
 include './../template/connection.php' ;
 include './../header/main_header.php' ;
 include './../header/main-sidebar.php' ;
 include './../header/aside.php';
 include './../header/header.php';

  $status = "";
  $check = $stmt = "";
  $id = $_GET['id'];
  // $gender = "";

  if (isset($_POST['update'])){
  $title         = $_POST['title'];
  $description   = $_POST['description'];
	
  $query = "
    UPDATE 
      `post` 
    SET 
      `title`       = :t,
      `description` = :d

    WHERE 
      `id` =  :id
  ";


//$check = "update Error:";
//if ($mysqli->query($query) === TRUE){  
//  $check = "update Success";
//}
  $stmt = $connection->prepare($query);
  $update = $stmt->execute([
    "t" => $title,
    "d" => $description,
    "id"=> $id
  ]);
  
  $check = "updated successfully";
  if($update == false){
    //echo $pdo->error();
    $check="updated Error:";
  }
  }
    $quer = $connection->prepare("SELECT * FROM `post` WHERE `id` = :id");
    $quer->execute(['id'=>$id]);
    $que  = $quer->fetch(PDO::FETCH_ASSOC);
  ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add post
      </h1>
      <ol class="breadcrumb">
        <li><a href="listing-post.php"><i class="fa fa-dashboard"></i> Listing</a></li>
        <li><a href="#"></a></li>
        <li class="active"></li>
      </ol>
    </section>
    <form method="post" enctype="multipart/form-data">
    <div class="container contact-form">
  <form method="post">
    <h3>Update !</h3>
    <p style="background-color: green ; color: black;width:300px;"><?php echo $check; ?> </p>              
    <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                          <input type="text" name="title" class="form-control" placeholder="title *" value="<?php echo !empty($que['title']) ? $que['title'] :'';?>"  />
                          <p><?php //echo $err; ?> </p>
                      </div>
                      <div class="box-body pad">
                        <form>
                          <textarea name = "description" class="textarea"  placeholder="description" value="<?php echo !empty($que['description']) ? $que['description'] :'';?>" 
                           style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
                        </form>
                        <p><?php //echo $err1; ?> </p>
                      </div>
      <div class="form-group">
        <input type="submit" name="update" class="btn-primary" value="Update" />
      </div>

  </div>	

  </form>
	
</div>
</div>
</form>
</div>
  <!-- /.content-wrapper -->
  <?php
  include "./header/footer.php";
  ?>