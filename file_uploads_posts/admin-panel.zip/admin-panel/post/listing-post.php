<?php
 include './../template/connection.php' ;
 include './../header/main_header.php' ;
 include './../header/main-sidebar.php' ;
 include './../header/aside.php';
 include './../header/header.php';


  $sort = $deletequery = $user= $message= "";
  $search  = !empty($_GET['search'])  ? $_GET['search'] : '';
  $orderBy = !empty($_GET['orderBy']) ? $_GET['orderBy'] : '';  
  $order   = !empty($_GET['order'])   ? $_GET['order'] : 'asc';
  $page    = !empty($_GET['page'])    ? $_GET['page'] : 1;
  //$id = $_GET['id'];
  $perPage   = 5;
  $limitrec  = ( $page - 1) * $perPage;


   # single row delete

  if( isset( $_GET['action'] ) && $_GET['action'] == 'delete' ){
    // $query  = "DELETE FROM `TABLE` WHERE `id` = '{$_GET['id']}'";
     $query = $connection->prepare("DELETE FROM `post` WHERE `id` = :id");
     $query->execute(['id'=>$_GET['id']]);
     
     if( $query == false ){
       echo "Error : delete";
     }else{
      $message = '<div class="alert alert-success" style="text-align:center;margin:3px;" role="alert">
      <h4 class="alert-heading">Successfully deleted !</h4>
      <p></p></div>'; 
      echo $message ;
       //echo "Deleted successfully";
        //header('location:http://localhost/pankajProject/9876-main/pdo/listing4.php');
     }
   }

  # Multi Delete Records
  if( isset( $_POST['multiDelete'] ) && $_POST['multiDelete'] == 'allDelete' ){
    $user = $_POST['user'];
    foreach( $user as $id ){ 
      $deletequery = ("DELETE FROM `post` WHERE `id` = :id");
      $stmt = $connection->prepare($deletequery);
      $stmt->execute(['id'=>$_GET['id']]);
      if( $deletequery == false ){
      echo "Error : delete";
      }else{
        $message = '<div class="alert alert-danger" role="alert">
      <h4 class="alert-heading">Successfully deleted!</h4>
      <p> </p></div>'; 
      echo $message ;
    
      }
    }
  }


  if(!empty( $_GET['search'] )){
    $search = " WHERE `title` LIKE :searchValue ||  `description` LIKE :searchValue ||  `id` LIKE :searchValue";
  }
 

  $order = ($order == 'asc') ? 'desc' : 'asc';
  if(!empty($orderBy) && !empty($order)){
      $sort = " ORDER BY `{$orderBy}` {$order}";
    }
  $query = "SELECT SQL_CALC_FOUND_ROWS * FROM `post` {$search} {$sort}  LIMIT :limitrec , :perPage ";

  #$result  = mysqli_query($con, $query);

  $fetch = $connection->prepare($query);
  if(!empty( $_GET['search'] )){
    $fetch-> bindValue(':searchValue', '%'.$_GET['search'].'%');
  }

  $fetch-> bindValue(':limitrec', $limitrec , PDO::PARAM_INT);
  $fetch-> bindValue(':perPage', $perPage, PDO::PARAM_INT);

  $fetch->execute();
  $fR = $connection->query("SELECT FOUND_ROWS() as totalRow");
  $tR = $fR->fetchColumn();
  $offset    = ceil( $tR / $perPage );
  $fetchall = $fetch->fetchAll(PDO::FETCH_ASSOC);

  
  ?>
  <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
     
      <ol class="breadcrumb">
        <li><a href="post-listing.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>

   
  

<div class = "form-group has-search">
<div class ="form-group has-search" style="float:left;padding:4px" >
<form method="get">
<input placeholder="Search..." name="search" >
</div>


<form method = "post">
    <div class = "select"  style="width:600px;float:right;">
  <select name = "multiDelete">
    <option value = "">SELECT</option>
    <option value = "allDelete">Delete</option>
  </select>
  <button class= "btn-danger"type="submit" name="all"  style="padding: 0px; width: 60px; ">Action</button>
  </div>



  <table class = "table table-bordered" style="">
    <thead thead class="thead-dark">
      <tr>
        <th> Select</th>
        <th> Serial No.</th>
        <th scope = "col">
          <a href = "listing-post.php?orderBy=id&order=<?php echo $order; ?>">ID</a>
        </th>
        <th scope = "col">
          <a href = "listing-post.php?orderBy=title&order=<?php echo $order; ?>">title</a> 
        </th>
      
        <th scope = "col">
          <a href = "listing-post.php?orderBy=image&order=<?php echo $order; ?>">image</a>
        </th>
        <th scope = "col">
          Action
        </th>
    </thead>
    <tbody class="tableBody">

      <?php if(empty($fetchall)){ $fetchall = [];?>      
        <tr><td>No Record Found</td></tr>
      <?php  } ?>


      <?php foreach($fetchall as $key => $values){?>
        <tr>
          <td> <input type = "checkbox" name = "user[]" value = "<?php echo $values['id']; ?>"> </td>
          <td><?php echo ++$limitrec;?> </td>
          <td><?php echo $values['id']; ?></td>
          <td><?php echo $values['title'];?></td>
    
          <td>
            <?php
              if( !empty($values['image']) ){
            ?>
              <img src="./../post-img/<?php echo $values['image']; ?>" width="50" height="50"/>
           <?php
              } 
            ?>
         </td>
          <td>


            <a href = "update-post.php?id=<?php echo $values['id']; ?>"><i class="fa fa-edit" aria-hidden="true"></i> </a>
            <a href = "?id=<?php echo $values['id']; ?>&action=delete" ><i class="fa fa-trash" aria-hidden="true"></i> </a>  
            


          </td>
        </tr> 
      <?php } ?>     
    </tbody>
  </table>
</form>

  <!-- <div class="pagination" style="margin: 0 auto;width: 20%;">
  <nav aria-label="page navigation">
    //
    //<?php//for($i=1;$i<=$totalpages;$i++){
   //   echo "<a href='./listing2.php?page={$i}' style='color:#fff;margin-left: 9px;padding: 1px 11px;'>".$i."</a>";
   // } 
    //?> -->

<nav aria-label = "page navigation example"style="text-align:center">
  <ul class = "pagination justify-content-center">
    <!-- <li class = "page-item disabled">
      <a class = "previous" href = <?php //if($page <= 1){ echo "" ; } else { echo "listing2.php?page=".($page - 1); } ?>>previous</a>
    </li> -->

    <li class="page-item ">
      <a class="page-link disabled" href="<?php if($page <= 1){ echo "" ; } else { echo "listing-post.php?page=".($page - 1); } ?>" tabindex="-1">Previous</a>
    </li>

    <?php for($i=1;$i<=$offset;$i++){ ?>
      <li class = "page-item ">
      <a class = "page-link active" href = "listing-post.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
    <?php } ?>
      <!-- <li class="page-item disabled">       
        <a class = "next" href = <?php// if($page >= $totalpages){ echo ""; } else { echo "listing2.php?page=".($page + 1); } ?>>Next</a>
      </li> -->
     
    <li class="page-item ">
      <a class="page-link" href="<?php if($page >= $offset){ echo ""; } else { echo "listing-post.php?page=".($page + 1); } ?>" tabindex="+1">Next</a>
    </li>

  </ul>
</nav>
  </div>
  <div class = "form-group" style = "float: right; margin-right:50px;">
  <button class = "btn btn-dark"><a href = "./register-post.php"> Create new post</a></button>
</div>


  <!-- /.content-wrapper -->
  <?php
  include "./../footer/footer.php";
  ?>