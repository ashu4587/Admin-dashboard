<?php
  include './../template/connection.php' ;
  include './../header/main_header.php' ;
  include './../header/main-sidebar.php' ;
  include './../header/aside.php';
  include './../header/header.php';

     $id=$_GET['id'];

   

        $msg = $err = $err1 = $err2 = $stack = "";
        if(isset($_POST['submit'])){
        if(isset($_FILES['image'])){ 
          $errors = array();
          $file_name = $_FILES['image']['name'];
          $file_size = $_FILES['image']['size'];
          $file_tmp = $_FILES['image']['tmp_name'];
          $file_type = $_FILES['image']['type'];
          $ext = explode('.',$file_name);
          $name = $ext[0];
          $file_ext   = strtolower(end($ext));
          $extensions = array("jpeg","jpg","png","mp4","");
              if(in_array($file_ext,$extensions)===false){
              $errors[] = "this extension file not allowed , please choose ajpg or png file";
            }
            if(empty($errors)==true){
              move_uploaded_file($file_tmp,"./../post-img/".$file_name);
            }else{
              print_r($errors);
              die(); 
            }
            }
            $title        = $_POST['title'];
            $description  = $_POST['description'];

            if(empty($title)){
              $stack = true;
              $err = "title is required*";
            }
            if(empty($description)){
              $stack = true;
              $err1 = "description is required*";
            }
            if(empty($file_name)){
              $stack = true;
              $err2 = "image is required*";
            }
            if($stack == false){
              // $insert = "INSERT INTO `TABLE` (`firstname`,`lastname`,`email`,`phone`,`gender`,`message`)
              // VALUES ('{$first}','{$last}','{$email}','{$gender}','{$message}')";
            
              $query = "INSERT INTO `post`
              (`title`, `description`,`image`,`user_id`)
              VALUES
              (:t,:d,:im,:id)";
              //print_r($query);
              $insert = $connection->prepare($query );
              $insert->execute(array(  
                  't'  => $title,
                  'd'  => $description,
                  'im' => $file_name,
                  'id' => $id

              ));
          
            
            // if($insert== true){
            //   header('Location:http://localhost/pankajProject/9876-main/pdo/listing4.php');
            // }
            if($insert == true){
              $title            = "";
              $description      = "";
              $file_name        = "";
              $success          = "alert alert-success";
              //header
              $msg              = "yay !! <br> Data inserted successfully";
            }else{
              //echo $mysqli->error;
              $msg = "There is an error to insert data";
              $success = "alert alert-danger";
            }
          }
          }

 ?>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
       Post
        <small></small>
      </h1>
      <ol class="breadcrumb">

        <li><a href="http://localhost/admin-panel/template/index.php">dashboard</a></li>
        <li class="active">post</li>
               <li><a href="listing-user.php"><i class="fa fa-dashboard"></i>Listing</a></li>
        
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
 

        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
          <form class="form-horizontal" method="post" enctype="multipart/form-data" > 
          <div style="text-align:center;"class="<?php echo $success;?> " >
                 <?php echo $msg ?>
              </div>

             <br>

               <div class="form-group">
                  <label for="title" class="col-sm-2 control-label">title:</label>
                  <div class="col-sm-5">
                    <input type="text" name="title" class="form-control" id="title" placeholder="title*"value="<?php echo(!empty($title)? $title:'');?>">
                    <p style="color:red;"><?php echo $err; ?></p>
                  </div>
                </div>

              
                <div class="form-group">
                  <label for="description" class="col-sm-2 control-label">description:</label>
                  <div class="col-sm-5">
                    <input type="text" name="description" class="form-control" id="description" placeholder="description*"value="<?php echo(!empty($description)? $description:'');?>">
                    <p style="color:red;"><?php echo $err1; ?></p>
                  </div>
                </div>

            <div class="form-group">
              <label for="image" class="col-sm-2 control-label">IMAGE:</label>
              <div class="col-sm-5">
                <input type="file" class="form-control" name="image"  id="image" name="image" value="<?php echo(!empty($file_name)? $file_name:'');?>">
                <p style="color:red;"><?php echo $err2; ?></p>
              </div>
            </div>


            <div class="form-group" style="text-align:center;">
            <button type="submit" name="submit" class="btn btn-primary" style="padding:2%;width:200px;padding: 1%;margin: 30px;font-size: x-large;">Submit</button>
          </div>
        </form>

              <!-- /.box-footer -->
         
          </div>
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php
  include "./../footer/footer.php";
  ?>