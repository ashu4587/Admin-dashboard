<?php
  include './../template/connection.php' ;
  include './../header/main_header.php' ;
  include './../header/main-sidebar.php' ;
  include './../header/aside.php';
  include './../header/header.php';
  
  ?>
  <!-- Content Wrapper. Contains page content -->
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      <h1>Gallery</h1>
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="listing-post.php"><i class="fa fa-dashboard"></i>Listing</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->


        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"></h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
  
<script src="https://code.jquery.com/jquery-2.2.4.js"></script>
    <script src = "jquery.fancybox.min.js"></script>
    <link href = "jquery.fancybox.min.css" rel = "stylesheet">
<style>
body{
    margin: 0;
    padding: 0;
    background: #ccc;
}
main{
  width: 80%;
  margin: 0px auto;
}
.thumbnails{
    width: 30%;
    float: left;
    margin: 10px;
    background: #fff;
    padding: 20px;
    box-sizing: border-box;
}
.thumbnails img{
    width: 100%;
    height: auto;
}
</style>
  </head>
  <body>
      <main>
      
      <?php
      $dir = glob('./../post-img/{*.jpg,*.png,*.webp}',GLOB_BRACE);
      foreach ($dir as $key => $value){
          ?>
          
          <div class ="thumbnails">
          <a href="<?php echo $value ?>" data-fancybox="images" data-caption="<?php echo $value ?>"></a>
          <img src ="<?php echo $value ?>" alt="<?php echo $value ?>">
          </div>
    <?php
      }
    ?>


    
     
       </main>
  </body>
  </div>
 
          </div>
          <!-- /.box -->
        </div>
        <!--/.col (right) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
</html>
 







 
  <?php
   include "./../footer/footer.php";
   ?>