<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.13
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="<?php echo URL;?>/Admin/dashboard.php">AdminLTE</a>.</strong> All rights
    reserved.
  </footer>
<!-- jQuery 3 -->
<script src="<?php echo URL;?>js/jquery.min.js"></script>
<script src="<?php echo URL;?>js/fontawesome.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo URL;?>js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo URL;?>js/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?php echo URL;?>js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo URL;?>js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo URL;?>js/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="<?php echo URL;?>js/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo URL;?>js/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="<?php echo URL;?>js/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="<?php echo URL;?>js/Chart.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo URL;?>js/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo URL;?>js/demo.js"></script>
</div>
</body>
</html>
