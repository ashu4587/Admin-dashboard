<?php 
  include '../database/connection.php';
  include PATH.DS.'header-footer'.DS.'header.php';
  include PATH.DS.'login'.DS.'login.php';
  include PATH.DS.'header-footer'.DS.'footer.php';
?>